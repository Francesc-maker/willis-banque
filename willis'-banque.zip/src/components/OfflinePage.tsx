import { motion } from 'motion/react';
import { WifiOff, ShieldAlert, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-[#080808] text-[#F4F4F4] flex items-center justify-center p-6">
      <div className="max-w-md w-full text-center space-y-10">
        <div className="relative inline-block">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="w-32 h-32 bg-primary/10 rounded-full flex items-center justify-center mx-auto"
          >
            <WifiOff className="w-16 h-16 text-primary" />
          </motion.div>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border-2 border-dashed border-primary/20 rounded-full"
          />
        </div>

        <div className="space-y-4">
          <h1 className="text-4xl font-serif italic text-primary tracking-tight">Connection Severed</h1>
          <p className="text-sm uppercase tracking-[4px] text-muted-foreground">Willis' Banque - Secure Offline Mode</p>
        </div>

        <div className="p-8 border border-border rounded-lg bg-card/50 space-y-6">
          <div className="flex items-center gap-3 justify-center text-primary">
            <ShieldAlert className="w-4 h-4" />
            <p className="text-[10px] uppercase tracking-widest">Security Protocol Active</p>
          </div>
          <p className="text-muted-foreground font-serif italic leading-relaxed">
            Your financial data remains encrypted and safe. Access to live market intelligence and 
            transaction synchronization is temporarily suspended until a secure link is re-established.
          </p>
        </div>

        <Button 
          onClick={() => window.location.reload()}
          className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-10 py-6 text-xs uppercase tracking-[3px]"
        >
          <RefreshCcw className="w-4 h-4 mr-2" />
          Attempt Reconnection
        </Button>

        <p className="text-[9px] uppercase tracking-[4px] text-muted-foreground italic">
          © Willis Group LLC • Sovereign Financial Systems
        </p>
      </div>
    </div>
  );
}
