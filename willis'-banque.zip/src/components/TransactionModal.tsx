import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TransactionType, CATEGORIES } from '@/src/types';

import {
  Dialog as ShadcnDialog,
  DialogContent as ShadcnDialogContent,
  DialogHeader as ShadcnDialogHeader,
  DialogTitle as ShadcnDialogTitle,
  DialogFooter as ShadcnDialogFooter,
} from "@/components/ui/dialog"

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (transaction: {
    amount: number;
    category: string;
    description: string;
    date: string;
    type: TransactionType;
  }) => void;
}

export default function TransactionModal({ isOpen, onClose, onAdd }: TransactionModalProps) {
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !category || !description) return;

    onAdd({
      amount: parseFloat(amount),
      category,
      description,
      date: new Date(date).toISOString(),
      type
    });

    // Reset form
    setAmount('');
    setCategory('');
    setDescription('');
    onClose();
  };

  return (
    <ShadcnDialog open={isOpen} onOpenChange={onClose}>
      <ShadcnDialogContent className="sm:max-w-[425px] bg-card border-border shadow-2xl">
        <ShadcnDialogHeader>
          <ShadcnDialogTitle className="text-primary font-serif italic text-2xl">New Transaction</ShadcnDialogTitle>
        </ShadcnDialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="grid grid-cols-2 gap-4">
            <Button
              type="button"
              variant="outline"
              className={`uppercase tracking-widest text-[10px] ${type === 'income' ? 'border-primary text-primary bg-primary/10' : 'border-border text-muted-foreground'}`}
              onClick={() => setType('income')}
            >
              Revenue
            </Button>
            <Button
              type="button"
              variant="outline"
              className={`uppercase tracking-widest text-[10px] ${type === 'expense' ? 'border-destructive text-destructive bg-destructive/10' : 'border-border text-muted-foreground'}`}
              onClick={() => setType('expense')}
            >
              Expenditure
            </Button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount" className="text-[11px] uppercase tracking-widest text-muted-foreground">Amount</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="0.00"
              className="bg-background border-border text-foreground focus:border-primary transition-colors"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="text-[11px] uppercase tracking-widest text-muted-foreground">Category</Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger className="bg-background border-border text-foreground">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                {CATEGORIES[type].map((cat) => (
                  <SelectItem key={cat} value={cat} className="text-foreground focus:bg-primary focus:text-primary-foreground">
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-[11px] uppercase tracking-widest text-muted-foreground">Description</Label>
            <Input
              id="description"
              placeholder="Transaction details"
              className="bg-background border-border text-foreground focus:border-primary transition-colors"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="date" className="text-[11px] uppercase tracking-widest text-muted-foreground">Date</Label>
            <Input
              id="date"
              type="date"
              className="bg-background border-border text-foreground focus:border-primary transition-colors"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          <ShadcnDialogFooter>
            <Button type="submit" className="w-full bg-primary text-primary-foreground hover:bg-primary/90 uppercase tracking-widest text-xs py-6">
              Commit Transaction
            </Button>
          </ShadcnDialogFooter>
        </form>
      </ShadcnDialogContent>
    </ShadcnDialog>
  );
}
