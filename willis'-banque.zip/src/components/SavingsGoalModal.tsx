import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog as ShadcnDialog,
  DialogContent as ShadcnDialogContent,
  DialogHeader as ShadcnDialogHeader,
  DialogTitle as ShadcnDialogTitle,
  DialogFooter as ShadcnDialogFooter,
} from "@/components/ui/dialog"

interface SavingsGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (goal: {
    title: string;
    targetAmount: number;
    currentAmount: number;
    monthlyAllocation: number;
  }) => void;
}

export default function SavingsGoalModal({ isOpen, onClose, onAdd }: SavingsGoalModalProps) {
  const [title, setTitle] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [currentAmount, setCurrentAmount] = useState('');
  const [monthlyAllocation, setMonthlyAllocation] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !targetAmount || !monthlyAllocation) return;

    onAdd({
      title,
      targetAmount: parseFloat(targetAmount),
      currentAmount: parseFloat(currentAmount || '0'),
      monthlyAllocation: parseFloat(monthlyAllocation),
    });

    // Reset form
    setTitle('');
    setTargetAmount('');
    setCurrentAmount('');
    setMonthlyAllocation('');
    onClose();
  };

  return (
    <ShadcnDialog open={isOpen} onOpenChange={onClose}>
      <ShadcnDialogContent className="sm:max-w-[425px] bg-card border-border shadow-2xl">
        <ShadcnDialogHeader>
          <ShadcnDialogTitle className="text-primary font-serif italic text-2xl">New Savings Goal</ShadcnDialogTitle>
        </ShadcnDialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-[11px] uppercase tracking-widest text-muted-foreground">Goal Title</Label>
            <Input
              id="title"
              placeholder="e.g. New Car, Vacation"
              className="bg-background border-border text-foreground focus:border-primary transition-colors"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="targetAmount" className="text-[11px] uppercase tracking-widest text-muted-foreground">Target Amount</Label>
            <Input
              id="targetAmount"
              type="number"
              step="0.01"
              placeholder="0.00"
              className="bg-background border-border text-foreground focus:border-primary transition-colors"
              value={targetAmount}
              onChange={(e) => setTargetAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="currentAmount" className="text-[11px] uppercase tracking-widest text-muted-foreground">Current Savings (Optional)</Label>
            <Input
              id="currentAmount"
              type="number"
              step="0.01"
              placeholder="0.00"
              className="bg-background border-border text-foreground focus:border-primary transition-colors"
              value={currentAmount}
              onChange={(e) => setCurrentAmount(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="monthlyAllocation" className="text-[11px] uppercase tracking-widest text-muted-foreground">Monthly Allocation</Label>
            <Input
              id="monthlyAllocation"
              type="number"
              step="0.01"
              placeholder="0.00"
              className="bg-background border-border text-foreground focus:border-primary transition-colors"
              value={monthlyAllocation}
              onChange={(e) => setMonthlyAllocation(e.target.value)}
              required
            />
          </div>

          <ShadcnDialogFooter>
            <Button type="submit" className="w-full bg-primary text-primary-foreground hover:bg-primary/90 uppercase tracking-widest text-xs py-6">
              Establish Goal
            </Button>
          </ShadcnDialogFooter>
        </form>
      </ShadcnDialogContent>
    </ShadcnDialog>
  );
}
