import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ArrowRightLeft, TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';

export default function CurrencyConverter() {
  const [usd, setUsd] = useState<string>('1');
  const [ksh, setKsh] = useState<string>('');
  const [rate, setRate] = useState<number>(129.50); // Default rate
  const [isUsdToKsh, setIsUsdToKsh] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  useEffect(() => {
    // In a real app, we'd fetch this from an API
    // For now, we simulate a slight fluctuation
    const interval = setInterval(() => {
      setRate(prev => prev + (Math.random() - 0.5) * 0.1);
      setLastUpdated(new Date());
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isUsdToKsh) {
      const val = parseFloat(usd);
      if (!isNaN(val)) setKsh((val * rate).toFixed(2));
      else setKsh('');
    } else {
      const val = parseFloat(ksh);
      if (!isNaN(val)) setUsd((val / rate).toFixed(2));
      else setUsd('');
    }
  }, [usd, ksh, rate, isUsdToKsh]);

  const handleUsdChange = (val: string) => {
    setUsd(val);
    if (!isUsdToKsh) setIsUsdToKsh(true);
  };

  const handleKshChange = (val: string) => {
    setKsh(val);
    if (isUsdToKsh) setIsUsdToKsh(false);
  };

  return (
    <div className="space-y-10 max-w-2xl mx-auto">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-serif italic text-primary">Currency Exchange</h2>
        <p className="text-xs uppercase tracking-[4px] text-muted-foreground">Real-time USD / KSH Conversion</p>
      </div>

      <Card className="bg-card border-border shadow-2xl">
        <CardHeader className="border-b border-border/50">
          <div className="flex justify-between items-center">
            <CardTitle className="text-sm uppercase tracking-widest text-muted-foreground">Market Rate</CardTitle>
            <div className="flex items-center gap-2 text-primary font-mono text-sm">
              <RefreshCw className="w-3 h-3 animate-spin-slow" />
              1 USD = {rate.toFixed(2)} KSH
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-10 space-y-8">
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-6">
            <div className="space-y-3">
              <label className="text-[10px] uppercase tracking-widest text-muted-foreground ml-1">United States Dollar</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-serif">$</span>
                <Input
                  type="number"
                  value={usd}
                  onChange={(e) => handleUsdChange(e.target.value)}
                  className="bg-background/50 border-border pl-8 py-8 text-2xl font-serif focus:ring-primary"
                  placeholder="0.00"
                />
              </div>
            </div>

            <Button 
              variant="ghost" 
              size="icon" 
              className="mt-6 text-primary hover:bg-primary/10 rounded-full h-12 w-12"
              onClick={() => setIsUsdToKsh(!isUsdToKsh)}
            >
              <ArrowRightLeft className={`w-6 h-6 transition-transform duration-500 ${!isUsdToKsh ? 'rotate-180' : ''}`} />
            </Button>

            <div className="space-y-3">
              <label className="text-[10px] uppercase tracking-widest text-muted-foreground ml-1">Kenyan Shilling</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-serif">KSh</span>
                <Input
                  type="number"
                  value={ksh}
                  onChange={(e) => handleKshChange(e.target.value)}
                  className="bg-background/50 border-border pl-12 py-8 text-2xl font-serif focus:ring-primary"
                  placeholder="0.00"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-lg bg-primary/5 border border-primary/10 flex justify-between items-center">
            <div className="space-y-1">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Conversion Summary</p>
              <p className="text-lg font-serif italic text-foreground">
                {usd || '0'} USD ≈ {ksh || '0'} KSH
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Last Updated</p>
              <p className="text-[10px] font-mono text-primary">{lastUpdated.toLocaleTimeString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-6">
        <div className="p-6 border border-border rounded-lg bg-card/30 space-y-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#A8C69F]" />
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Buy Rate</p>
          </div>
          <p className="text-xl font-serif">{(rate * 0.98).toFixed(2)} KSH</p>
        </div>
        <div className="p-6 border border-border rounded-lg bg-card/30 space-y-3">
          <div className="flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-[#C69F9F]" />
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Sell Rate</p>
          </div>
          <p className="text-xl font-serif">{(rate * 1.02).toFixed(2)} KSH</p>
        </div>
      </div>
    </div>
  );
}
