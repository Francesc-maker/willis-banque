import { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, ArrowUpCircle, ArrowDownCircle, Wallet, History, PieChart as PieChartIcon, LogOut, LayoutDashboard, TrendingUp, TrendingDown, Briefcase, Target, Trash2, Bell, AlertTriangle, CheckCircle, Info, Shield, Phone, Users, Landmark, Mail, Palette, Globe, Newspaper } from 'lucide-react';
import { Transaction, CATEGORIES, SavingsGoal, UserProfile } from '@/src/types';
import CurrencyConverter from './CurrencyConverter';
import { format, parseISO, startOfWeek, isAfter, subDays } from 'date-fns';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';

interface DashboardProps {
  transactions: Transaction[];
  savingsGoals: SavingsGoal[];
  userProfile: UserProfile | null;
  theme: string;
  onThemeChange: (theme: string) => void;
  onAddTransaction: (t: Omit<Transaction, 'id' | 'userId'>) => void;
  onDeleteSavingsGoal: (id: string) => void;
  onUpdateSavingsGoal: (id: string, amount: number) => void;
  onLogout: () => void;
}

export default function Dashboard({ transactions, savingsGoals, userProfile, theme, onThemeChange, onLogout, onDeleteSavingsGoal, onUpdateSavingsGoal }: DashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => 
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [transactions, searchQuery]);

  const stats = useMemo(() => {
    const income = transactions
      .filter(t => t.type === 'income')
      .reduce((acc, t) => acc + t.amount, 0);
    const expenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => acc + t.amount, 0);
    
    const totalSavings = savingsGoals.reduce((acc, g) => acc + g.currentAmount, 0);
    
    return {
      income,
      expenses,
      balance: income - expenses,
      totalSavings,
      netWorth: (income - expenses) + totalSavings
    };
  }, [transactions, savingsGoals]);

  const notifications = useMemo(() => {
    const alerts: { id: string; type: 'warning' | 'success' | 'info'; message: string; icon: any }[] = [];
    
    // Low balance warning
    if (stats.balance < 500) {
      alerts.push({
        id: 'low-balance',
        type: 'warning',
        message: 'Low balance warning: Liquidity below $500 threshold.',
        icon: AlertTriangle
      });
    }

    // Goal reached
    savingsGoals.forEach(goal => {
      if (goal.currentAmount >= goal.targetAmount) {
        alerts.push({
          id: `goal-${goal.id}`,
          type: 'success',
          message: `Goal reached: ${goal.title} is now fully funded.`,
          icon: CheckCircle
        });
      }
    });

    // Spending too fast (expenses in last 7 days > 50% of monthly income)
    const last7Days = subDays(new Date(), 7);
    const recentExpenses = transactions
      .filter(t => t.type === 'expense' && isAfter(parseISO(t.date), last7Days))
      .reduce((acc, t) => acc + t.amount, 0);
    
    if (stats.income > 0 && recentExpenses > stats.income * 0.5) {
      alerts.push({
        id: 'spending-fast',
        type: 'warning',
        message: "You're spending too fast this week. Review your recent activity.",
        icon: TrendingDown
      });
    }

    if (alerts.length === 0) {
      alerts.push({
        id: 'all-good',
        type: 'info',
        message: 'Financial health stable. No urgent alerts.',
        icon: Info
      });
    }

    return alerts;
  }, [stats, savingsGoals, transactions]);

  const chartData = useMemo(() => {
    const data: Record<string, { income: number; expense: number }> = {};
    transactions.forEach(t => {
      const date = format(parseISO(t.date), 'MMM dd');
      if (!data[date]) data[date] = { income: 0, expense: 0 };
      if (t.type === 'income') data[date].income += t.amount;
      else data[date].expense += t.amount;
    });
    return Object.entries(data)
      .map(([name, values]) => ({ name, ...values }))
      .sort((a, b) => parseISO(a.name).getTime() - parseISO(b.name).getTime())
      .slice(-12); // Last 12 entries
  }, [transactions]);

  const categoryData = useMemo(() => {
    const data: Record<string, number> = {};
    transactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        data[t.category] = (data[t.category] || 0) + t.amount;
      });
    return Object.entries(data).map(([name, value]) => ({ name, value }));
  }, [transactions]);

  const COLORS = ['#D4AF37', '#A8C69F', '#C69F9F', '#8E9299', '#5A5A40', '#1a1a1a'];

  const navItems = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'income', label: 'Income', icon: TrendingUp },
    { id: 'expenditure', label: 'Expenditure', icon: TrendingDown },
    { id: 'investments', label: 'Investments', icon: Briefcase },
    { id: 'exchange', label: 'Exchange', icon: Globe },
    { id: 'trustees', label: 'Trustees', icon: Shield },
    { id: 'history', label: 'History', icon: History },
  ];

  const trustees = [
    { role: 'Founder & Chairman', name: 'Francesc Willis', icon: Users },
    { role: 'Primary Subsidiary', name: 'Equity Group', icon: Landmark },
    { role: 'Global Compliance', name: 'Willis Group LLC', icon: Shield },
  ];

  const supportContacts = [
    { label: 'Official Support', value: 'willisgroupLLCco.gmail.com' },
  ];

  const marketIntelligence = [
    { title: 'Global Equity Outlook', impact: 'Positive', summary: 'Willis Group analysts project a 12% growth in private equity sectors.' },
    { title: 'Currency Volatility', impact: 'Neutral', summary: 'USD remains stable against major pairs; hedging strategies recommended.' },
    { title: 'New Asset Class', impact: 'High', summary: 'Introduction of Digital Sovereign Bonds for private banking clients.' },
  ];

  const themes = [
    { id: 'gold', label: 'Royal Gold', color: '#D4AF37' },
    { id: 'emerald', label: 'Midnight Emerald', color: '#50C878' },
    { id: 'silver', label: 'Imperial Silver', color: '#C0C0C0' },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex overflow-hidden">
      {/* Sidebar */}
      <aside className="w-[280px] border-r border-border p-10 flex flex-col justify-between shrink-0">
        <div>
          <div className="logo text-2xl font-serif italic tracking-wider text-primary mb-16">
            Willis' Banque
          </div>
          <nav>
            <ul className="space-y-6">
              {navItems.map((item) => (
                <li 
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-3 text-sm uppercase tracking-[2px] cursor-pointer transition-colors ${
                    activeTab === item.id ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div className="space-y-6">
          <div className="bg-card p-6 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-4">
              <Palette className="w-4 h-4 text-primary" />
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Atmosphere</p>
            </div>
            <div className="flex gap-3">
              {themes.map((t) => (
                <button
                  key={t.id}
                  onClick={() => onThemeChange(t.id)}
                  className={`w-8 h-8 rounded-full border-2 transition-all ${
                    theme === t.id ? 'border-primary scale-110' : 'border-transparent opacity-50 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: t.color }}
                  title={t.label}
                />
              ))}
            </div>
          </div>

          <div className="bg-card p-6 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-4">
              <Mail className="w-4 h-4 text-primary" />
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Support</p>
            </div>
            <div className="space-y-3">
              {supportContacts.map((s, i) => (
                <div key={i} className="space-y-1">
                  <p className="text-[9px] uppercase tracking-widest text-muted-foreground">{s.label}</p>
                  <p className="text-[10px] font-mono text-primary break-all">{s.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card p-6 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-4">
              <Bell className="w-4 h-4 text-primary" />
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Intelligence</p>
            </div>
            <div className="space-y-4">
              {notifications.slice(0, 2).map(alert => (
                <div key={alert.id} className="flex gap-3 items-start">
                  <alert.icon className={`w-3 h-3 mt-0.5 ${alert.type === 'warning' ? 'text-destructive' : alert.type === 'success' ? 'text-[#A8C69F]' : 'text-primary'}`} />
                  <p className="text-[10px] leading-relaxed text-muted-foreground italic font-serif">{alert.message}</p>
                </div>
              ))}
            </div>
          </div>
          <Button variant="ghost" className="w-full text-muted-foreground hover:text-primary" onClick={onLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-16 overflow-y-auto grid grid-rows-[auto_1fr_auto] gap-10">
        {/* Header */}
        <div className="flex justify-between items-end">
          <div>
            <p className="font-serif italic text-muted-foreground text-lg">
              {userProfile?.entityName || 'Private Client'} • Net Worth
            </p>
            <h1 className="text-[64px] font-light tracking-tighter mt-2 leading-none">
              ${stats.netWorth.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </h1>
          </div>
          <div className="text-right font-serif italic text-sm text-muted-foreground leading-relaxed">
            Acct: **** 8821<br />
            {userProfile?.bankingReason || 'Private Banking Tier'}
          </div>
        </div>

        {/* Content Area */}
        <div className="space-y-10">
          {activeTab === 'overview' && (
            <>
              <div className="grid grid-cols-4 gap-10">
                <div className="p-6 border-b border-border">
                  <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Total Cash</p>
                  <p className="text-2xl font-serif text-foreground">
                    ${stats.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="p-6 border-b border-border">
                  <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Total Savings</p>
                  <p className="text-2xl font-serif text-primary">
                    ${stats.totalSavings.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="p-6 border-b border-border">
                  <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Age / Recovery</p>
                  <p className="text-xl font-serif text-foreground">
                    {userProfile?.age || '--'} • {userProfile?.recoveryNumber || 'Not Set'}
                  </p>
                </div>
                <div className="p-6 border-b border-border">
                  <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Monthly Flow</p>
                  <p className={`text-2xl font-serif ${stats.income - stats.expenses >= 0 ? 'text-[#A8C69F]' : 'text-[#C69F9F]'}`}>
                    {stats.income - stats.expenses >= 0 ? '+' : '-'}${Math.abs(stats.income - stats.expenses).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                <div className="lg:col-span-2 space-y-6">
                  <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Cash Flow Trajectory</p>
                  <div className="h-[200px] w-full border-b border-border pb-5 flex items-end gap-3">
                    {chartData.map((d, i) => (
                      <div 
                        key={i} 
                        className={`flex-1 rounded-t-sm relative transition-all duration-500 ${
                          i === chartData.length - 1 
                            ? 'bg-gradient-to-t from-primary to-transparent opacity-80' 
                            : 'bg-border'
                        }`}
                        style={{ height: `${Math.max(10, (d.income / (stats.income || 1)) * 100)}%` }}
                      />
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Globe className="w-4 h-4 text-primary" />
                    <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Market Intelligence</p>
                  </div>
                  <div className="space-y-4">
                    {marketIntelligence.map((item, i) => (
                      <div key={i} className="p-4 border border-border rounded bg-card/50 space-y-2">
                        <div className="flex justify-between items-center">
                          <p className="text-xs font-serif italic text-primary">{item.title}</p>
                          <span className={`text-[8px] uppercase tracking-widest px-2 py-0.5 rounded-full ${
                            item.impact === 'Positive' ? 'bg-[#A8C69F]/20 text-[#A8C69F]' : 
                            item.impact === 'High' ? 'bg-primary/20 text-primary' : 
                            'bg-muted text-muted-foreground'
                          }`}>
                            {item.impact}
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground leading-relaxed">{item.summary}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Goals Progress</p>
                  <p className="text-2xl font-serif">
                    {savingsGoals.length > 0 
                      ? Math.round((stats.totalSavings / savingsGoals.reduce((acc, g) => acc + g.targetAmount, 0)) * 100) 
                      : 0}% Complete
                  </p>
                </div>
                <div className="px-6 py-3 border border-primary text-primary text-[13px] rounded-full uppercase tracking-widest">
                  Total Assets: ${(stats.balance + stats.totalSavings).toLocaleString()}
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-2">
                  <History className="w-4 h-4 text-primary" />
                  <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Recent Activity</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {transactions.slice(0, 4).map(t => (
                    <div key={t.id} className="flex justify-between items-center p-4 border border-border rounded bg-card/30">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${t.type === 'income' ? 'bg-[#A8C69F]/10 text-[#A8C69F]' : 'bg-[#C69F9F]/10 text-[#C69F9F]'}`}>
                          {t.type === 'income' ? <ArrowUpCircle className="w-4 h-4" /> : <ArrowDownCircle className="w-4 h-4" />}
                        </div>
                        <div>
                          <p className="text-sm font-serif italic">{t.description}</p>
                          <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{t.category}</p>
                        </div>
                      </div>
                      <p className={`text-sm font-serif ${t.type === 'income' ? 'text-[#A8C69F]' : 'text-[#C69F9F]'}`}>
                        {t.type === 'income' ? '+' : '-'}${t.amount.toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === 'exchange' && (
            <CurrencyConverter />
          )}

          {activeTab === 'trustees' && (
            <div className="space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                {trustees.map((t, i) => (
                  <Card key={i} className="bg-card border-border p-8 text-center space-y-4">
                    <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                      <t.icon className="w-8 h-8 text-primary" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-[4px] text-muted-foreground mb-1">{t.role}</p>
                      <p className="text-2xl font-serif italic text-primary">{t.name}</p>
                    </div>
                  </Card>
                ))}
              </div>
              
              <div className="p-10 border border-border rounded-lg bg-card/30">
                <h3 className="text-primary text-sm uppercase tracking-[4px] mb-6">Organizational Charter</h3>
                <p className="font-serif italic text-muted-foreground leading-relaxed text-lg">
                  "Willis' Banque operates under the direct stewardship of the Willis Group LLC, 
                  with strategic oversight provided by the Equity Group. Our mission is to provide 
                  unparalleled financial sovereignty to our private members, ensuring that every 
                  transaction reinforces the legacy of our founders."
                </p>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-serif italic text-primary">Transaction Ledger</h2>
                <div className="relative w-64">
                  <input
                    type="text"
                    placeholder="Search ledger..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-card border border-border rounded-full px-4 py-2 text-xs focus:outline-none focus:border-primary transition-colors"
                  />
                </div>
              </div>
              <div className="space-y-4">
                {filteredTransactions.length === 0 ? (
                  <p className="text-muted-foreground italic font-serif text-center py-10">No records found matching your query.</p>
                ) : (
                  filteredTransactions.map(t => (
                    <div key={t.id} className="flex justify-between items-center p-4 border-b border-border hover:bg-card/50 transition-colors">
                      <div>
                        <p className="font-serif italic text-lg">{t.description}</p>
                        <p className="text-[11px] uppercase tracking-widest text-muted-foreground">{t.category} • {format(parseISO(t.date), 'MMM dd, yyyy')}</p>
                      </div>
                      <p className={`text-xl font-serif ${t.type === 'income' ? 'text-[#A8C69F]' : 'text-[#C69F9F]'}`}>
                        {t.type === 'income' ? '+' : '-'}${t.amount.toLocaleString()}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === 'investments' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <Card className="bg-card border-border shadow-none">
                <CardHeader>
                  <CardTitle className="text-primary font-serif italic">Portfolio Allocation</CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#121212', borderColor: '#D4AF37' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-primary text-lg uppercase tracking-widest">Savings Goals</h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-primary hover:text-primary/80"
                    onClick={() => (window as any).openSavingsGoalModal()}
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    New Goal
                  </Button>
                </div>
                <div className="space-y-8">
                  {savingsGoals.length === 0 ? (
                    <p className="text-muted-foreground italic font-serif text-sm">No active goals established.</p>
                  ) : (
                    savingsGoals.map(goal => {
                      const progress = Math.min(100, (goal.currentAmount / goal.targetAmount) * 100);
                      const remaining = 100 - progress;
                      return (
                        <div key={goal.id} className="space-y-3 group">
                          <div className="flex justify-between items-start">
                            <div className="space-y-1">
                              <p className="text-sm uppercase tracking-widest font-medium">{goal.title}</p>
                              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">
                                Allocation: ${goal.monthlyAllocation.toLocaleString()}/mo • {remaining.toFixed(1)}% Remaining
                              </p>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="text-xs font-serif italic text-primary">
                                ${goal.currentAmount.toLocaleString()} / ${goal.targetAmount.toLocaleString()}
                              </span>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-6 w-6 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => onDeleteSavingsGoal(goal.id)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="w-full h-[2px] bg-border rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${progress}%` }}
                              className="h-full bg-primary shadow-[0_0_10px_#D4AF37]"
                            />
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex justify-between items-center">
          <p className="text-[10px] uppercase tracking-[3px] text-muted-foreground font-serif italic">
            © Willis Group LLC
          </p>
          <Button 
            className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 py-6 text-sm uppercase tracking-widest"
            onClick={() => (window as any).openTransactionModal()}
          >
            <Plus className="w-4 h-4 mr-2" />
            New Entry
          </Button>
        </div>
      </main>
    </div>
  );
}
