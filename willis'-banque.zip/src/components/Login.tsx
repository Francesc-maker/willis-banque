import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ShieldCheck, ArrowRight, Mail, Lock, Chrome } from 'lucide-react';
import { auth, signInWithGoogle, createUserWithEmailAndPassword, signInWithEmailAndPassword } from '../firebase';
import { toast } from 'sonner';

interface LoginProps {
  onSuccess: () => void;
}

export default function Login({ onSuccess }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [age, setAge] = useState('');
  const [recoveryNumber, setRecoveryNumber] = useState('');
  const [bankingReason, setBankingReason] = useState('');
  const [entityName, setEntityName] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setIsLoading(true);

    try {
      if (isSignUp) {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        // We'll store the extra fields in Firestore in App.tsx after PIN entry
        // but we can pass them via a custom event or state if needed.
        // For now, let's just use local storage to pass them to App.tsx temporarily
        // or better, modify the onSuccess to take these values.
        (window as any).pendingProfileData = {
          age: parseInt(age),
          recoveryNumber,
          bankingReason,
          entityName
        };
        toast.success('Account created successfully');
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        toast.success('Welcome back');
      }
      onSuccess();
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      await signInWithGoogle();
      toast.success('Identity Verified');
      onSuccess();
    } catch (error: any) {
      console.error(error);
      toast.error('Google authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <Card className="bg-card border-border shadow-2xl p-8">
          <CardHeader className="text-center p-0 mb-10">
            <div className="logo text-4xl font-serif italic text-primary mb-6">Willis' Banque</div>
            <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-6">
              <ShieldCheck className="w-6 h-6 text-primary" />
            </div>
            <CardTitle className="text-sm uppercase tracking-[4px] text-muted-foreground">
              {isSignUp ? 'Create Account' : 'Secure Access'}
            </CardTitle>
            <CardDescription className="font-serif italic text-muted-foreground mt-2">
              {isSignUp 
                ? 'Join the elite banking circle' 
                : 'Enter your credentials to access the private vault'}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <form onSubmit={handleEmailAuth} className="space-y-6">
              <div className="space-y-4">
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="Email Address"
                    value={email}
                    disabled={isLoading}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-background border-border pl-10 h-12 focus:border-primary transition-all"
                    required
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="Password"
                    value={password}
                    disabled={isLoading}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-background border-border pl-10 h-12 focus:border-primary transition-all"
                    required
                  />
                </div>

                {isSignUp && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-4 pt-2 border-t border-border mt-4"
                  >
                    <Input
                      placeholder="Individual or Company Name"
                      value={entityName}
                      disabled={isLoading}
                      onChange={(e) => setEntityName(e.target.value)}
                      className="bg-background border-border h-12 focus:border-primary transition-all"
                      required
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        type="number"
                        placeholder="Age"
                        value={age}
                        disabled={isLoading}
                        onChange={(e) => setAge(e.target.value)}
                        className="bg-background border-border h-12 focus:border-primary transition-all"
                        required
                      />
                      <Input
                        type="tel"
                        placeholder="Recovery Number"
                        value={recoveryNumber}
                        disabled={isLoading}
                        onChange={(e) => setRecoveryNumber(e.target.value)}
                        className="bg-background border-border h-12 focus:border-primary transition-all"
                        required
                      />
                    </div>
                    <Input
                      placeholder="Reason for Banking"
                      value={bankingReason}
                      disabled={isLoading}
                      onChange={(e) => setBankingReason(e.target.value)}
                      className="bg-background border-border h-12 focus:border-primary transition-all"
                      required
                    />
                  </motion.div>
                )}
              </div>

              <Button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-full py-6 text-xs uppercase tracking-widest font-bold"
              >
                {isLoading ? 'Verifying...' : (isSignUp ? 'Establish Account' : 'Authenticate')}
                {!isLoading && <ArrowRight className="w-4 h-4 ml-2" />}
              </Button>

              <div className="relative py-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-[10px] uppercase tracking-widest">
                  <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
                </div>
              </div>

              <Button 
                type="button"
                variant="outline"
                disabled={isLoading}
                onClick={handleGoogleAuth}
                className="w-full border-border hover:bg-muted text-xs uppercase tracking-widest py-6"
              >
                <Chrome className="w-4 h-4 mr-2" />
                Google Identity
              </Button>

              <p className="text-center text-[11px] text-muted-foreground uppercase tracking-widest mt-6">
                {isSignUp ? 'Already a member?' : 'Not a member yet?'}
                <button
                  type="button"
                  onClick={() => setIsSignUp(!isSignUp)}
                  className="ml-2 text-primary hover:underline font-bold"
                >
                  {isSignUp ? 'Sign In' : 'Join Now'}
                </button>
              </p>
            </form>

            <div className="mt-12 pt-8 border-t border-border text-center">
              <p className="text-[10px] uppercase tracking-[3px] text-muted-foreground font-serif italic">
                Willis Group LLC • Private Banking
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
