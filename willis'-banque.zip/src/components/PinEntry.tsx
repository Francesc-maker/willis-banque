import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Lock, Delete } from 'lucide-react';

interface PinEntryProps {
  onSuccess: () => void;
  storedPin: string | null;
  onSetPin: (pin: string) => void;
}

export default function PinEntry({ onSuccess, storedPin, onSetPin }: PinEntryProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [isSetting, setIsSetting] = useState(!storedPin);
  const [confirmPin, setConfirmPin] = useState('');
  const [step, setStep] = useState(1);

  const handleNumberClick = (num: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + num);
      setError(false);
    }
  };

  const handleDelete = () => {
    setPin(prev => prev.slice(0, -1));
  };

  useEffect(() => {
    if (pin.length === 4) {
      if (isSetting) {
        if (step === 1) {
          setConfirmPin(pin);
          setPin('');
          setStep(2);
        } else {
          if (pin === confirmPin) {
            onSetPin(pin);
            onSuccess();
          } else {
            setError(true);
            setPin('');
            setStep(1);
            setConfirmPin('');
          }
        }
      } else {
        if (pin === storedPin) {
          onSuccess();
        } else {
          setError(true);
          setPin('');
        }
      }
    }
  }, [pin, isSetting, step, confirmPin, storedPin, onSetPin, onSuccess]);

  const numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'delete'];

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md"
      >
        <Card className="bg-card border-border shadow-2xl p-8">
          <CardHeader className="text-center p-0 mb-10">
            <div className="logo text-3xl font-serif italic text-primary mb-6">Willis' Banque</div>
            <CardTitle className="text-sm uppercase tracking-[3px] text-muted-foreground">
              {isSetting ? (step === 1 ? 'Establish Access' : 'Confirm Access') : "Private Access"}
            </CardTitle>
            <CardDescription className="font-serif italic text-muted-foreground mt-2">
              {isSetting ? 'Secure your private banking tier' : 'Enter your credentials to proceed'}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="flex justify-center gap-6 mb-12">
              {[...Array(4)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={error ? { x: [0, -10, 10, -10, 10, 0] } : {}}
                  transition={{ duration: 0.4 }}
                  className={`w-3 h-3 rounded-full border border-primary/30 transition-all duration-300 ${
                    pin.length > i ? 'bg-primary shadow-[0_0_15px_#D4AF37]' : 'bg-transparent'
                  }`}
                />
              ))}
            </div>

            <div className="grid grid-cols-3 gap-6 max-w-[300px] mx-auto">
              {numbers.map((num, i) => {
                if (num === '') return <div key={i} />;
                if (num === 'delete') {
                  return (
                    <Button
                      key={i}
                      variant="ghost"
                      className="h-16 text-muted-foreground hover:text-primary transition-colors"
                      onClick={handleDelete}
                    >
                      <Delete className="w-5 h-5" />
                    </Button>
                  );
                }
                return (
                  <Button
                    key={i}
                    variant="ghost"
                    className="h-16 text-2xl font-light hover:text-primary hover:bg-transparent transition-all"
                    onClick={() => handleNumberClick(num)}
                  >
                    {num}
                  </Button>
                );
              })}
            </div>

            {error && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-destructive text-center mt-8 text-xs uppercase tracking-widest"
              >
                Access Denied. Try Again.
              </motion.p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
