/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Toaster, toast } from 'sonner';
import Login from './components/Login';
import PinEntry from './components/PinEntry';
import Dashboard from './components/Dashboard';
import OfflinePage from './components/OfflinePage';
import TransactionModal from './components/TransactionModal';
import SavingsGoalModal from './components/SavingsGoalModal';
import { Transaction, UserProfile, SavingsGoal } from './types';
import { auth, db, signInWithGoogle, logout } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  doc, 
  getDoc, 
  setDoc,
  Timestamp,
  orderBy,
  deleteDoc,
  updateDoc
} from 'firebase/firestore';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  toast.error("Database error. Please check your connection.");
  throw new Error(JSON.stringify(errInfo));
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [theme, setTheme] = useState(() => localStorage.getItem('willis-theme') || 'gold');

  // Theme effect
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('willis-theme', theme);
  }, [theme]);

  // Online Status Listener
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            setUserProfile(userDoc.data() as UserProfile);
          } else {
            setUserProfile(null);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
        }
      } else {
        setUserProfile(null);
        setIsAuthenticated(false);
      }
      setIsAuthReady(true);
    });
    return unsubscribe;
  }, []);

  // Transactions Listener
  useEffect(() => {
    if (!user || !isAuthenticated) {
      setTransactions([]);
      return;
    }

    const q = query(
      collection(db, 'transactions'),
      where('userId', '==', user.uid),
      orderBy('date', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const txs = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          date: data.date instanceof Timestamp ? data.date.toDate().toISOString() : data.date
        } as Transaction;
      });
      setTransactions(txs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'transactions');
    });

    return unsubscribe;
  }, [user, isAuthenticated]);

  // Savings Goals Listener
  useEffect(() => {
    if (!user || !isAuthenticated) {
      setSavingsGoals([]);
      return;
    }

    const q = query(
      collection(db, 'savings_goals'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const goals = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: data.createdAt instanceof Timestamp ? data.createdAt.toDate().toISOString() : data.createdAt
        } as SavingsGoal;
      });
      setSavingsGoals(goals);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'savings_goals');
    });

    return unsubscribe;
  }, [user, isAuthenticated]);

  const handleSetPin = async (pin: string) => {
    if (!user) return;
    const pendingData = (window as any).pendingProfileData || {};
    const profile: UserProfile = {
      uid: user.uid,
      email: user.email || '',
      displayName: pendingData.entityName || user.displayName || 'Willis',
      pin,
      currency: 'USD',
      ...pendingData
    };
    try {
      await setDoc(doc(db, 'users', user.uid), profile);
      setUserProfile(profile);
      delete (window as any).pendingProfileData;
      toast.success('PIN set successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const handleAddTransaction = async (data: Omit<Transaction, 'id' | 'userId'>) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'transactions'), {
        ...data,
        date: Timestamp.fromDate(new Date(data.date)),
        userId: user.uid
      });
      toast.success('Transaction added!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'transactions');
    }
  };

  const handleAddSavingsGoal = async (data: Omit<SavingsGoal, 'id' | 'userId' | 'createdAt'>) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'savings_goals'), {
        ...data,
        createdAt: Timestamp.now(),
        userId: user.uid
      });
      toast.success('Savings goal established!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'savings_goals');
    }
  };

  const handleDeleteSavingsGoal = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'savings_goals', id));
      toast.success('Goal removed');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `savings_goals/${id}`);
    }
  };

  const handleUpdateSavingsGoal = async (id: string, amount: number) => {
    try {
      await updateDoc(doc(db, 'savings_goals', id), {
        currentAmount: amount
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `savings_goals/${id}`);
    }
  };

  const handleLogout = async () => {
    await logout();
    setIsAuthenticated(false);
    toast.info('Logged out safely');
  };

  // Expose modal triggers
  useEffect(() => {
    (window as any).openTransactionModal = () => setIsModalOpen(true);
    (window as any).openSavingsGoalModal = () => setIsGoalModalOpen(true);
  }, []);

  if (!isOnline) return <OfflinePage />;

  if (!isAuthReady) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  // Step 1: Identity Verification (Login/Sign-up)
  if (!user) {
    return (
      <>
        <Toaster position="top-center" richColors />
        <Login onSuccess={() => {}} />
      </>
    );
  }

  return (
    <>
      <Toaster position="top-center" richColors />
      {!isAuthenticated ? (
        <PinEntry
          storedPin={userProfile?.pin || null}
          onSuccess={() => setIsAuthenticated(true)}
          onSetPin={handleSetPin}
        />
      ) : (
        <Dashboard
          transactions={transactions}
          savingsGoals={savingsGoals}
          userProfile={userProfile}
          theme={theme}
          onThemeChange={setTheme}
          onAddTransaction={handleAddTransaction}
          onDeleteSavingsGoal={handleDeleteSavingsGoal}
          onUpdateSavingsGoal={handleUpdateSavingsGoal}
          onLogout={handleLogout}
        />
      )}
      <TransactionModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddTransaction}
      />
      <SavingsGoalModal
        isOpen={isGoalModalOpen}
        onClose={() => setIsGoalModalOpen(false)}
        onAdd={handleAddSavingsGoal}
      />
    </>
  );
}

