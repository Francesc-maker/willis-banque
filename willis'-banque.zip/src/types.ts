export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string; // ISO string
  type: TransactionType;
  userId: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  pin: string;
  currency: string;
  age?: number;
  recoveryNumber?: string;
  bankingReason?: string;
  entityName?: string; // Company or individual name
}

export interface SavingsGoal {
  id: string;
  userId: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  monthlyAllocation: number;
  createdAt: string;
}

export const CATEGORIES = {
  income: [
    'Salary',
    'Freelance',
    'Investment',
    'Gift',
    'Other'
  ],
  expense: [
    'Food',
    'Rent',
    'Utilities',
    'Transport',
    'Entertainment',
    'Shopping',
    'Health',
    'Education',
    'Other'
  ]
};
